package com.darkthor.product_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
