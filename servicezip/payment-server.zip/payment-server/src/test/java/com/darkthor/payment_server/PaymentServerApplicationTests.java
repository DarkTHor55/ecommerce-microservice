package com.darkthor.payment_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaymentServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
